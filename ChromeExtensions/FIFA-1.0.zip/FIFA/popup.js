var FifaWorldCup2014 = {

  matchesUrl: 'http://lup.fifa.com/live/common/competitions/worldcup/_feed/_listmachlive.js',
  liveMatchId: null,
  nextMatchId: null,
  nextMatchTime: null,
  liveMatchScore: null, 
  tournmentEndDate: new Date(2014,6,15),
  secondStageStartDate: new Date(2014,5,27),
  
  requestOngoingMatchesInfo: function() {
	  
	  $("#matchSummary").empty();
	  
	  var curDate = new Date();
	  if(curDate.getTime() > this.tournmentEndDate.getTime()) {
		  var message = 'The tournment has ended.. It is always a good idea to clean up after yourself. Please uninstall this extension by right-clicking on the icon and choosing to remove from Chrome. Thank you very much for your support.';
		  $("#matchSummary").html(message);
		  return;
	  }
	  
	  var req = new XMLHttpRequest();
	  req.open("GET", this.matchesUrl, true);
	  req.onload = this.processOngoingMatchesInfo.bind(this);
	  req.send(null);
  },
  
  processOngoingMatchesInfo: function(e) {
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var ongoingObj = JSON.parse(jsonText);
	  var matches = ongoingObj['matches'];
	  //console.log('Number of matches :'+matches.length);
	  var livematches = $.grep(matches, function(o,i) {
		  return o['s']==='live';
	  });
	  
	  var upcomingmatches = $.grep(matches, function(o,i) {
		  return o['s']==='fixture';
	  });
	  
	  upcomingmatches = upcomingmatches.sort(function(a,b) {
		  if(new Date(a["dt"]).getTime()>new Date(b["dt"]).getTime()) {
			  return 1;
		  } else if(new Date(a["dt"]).getTime()<new Date(b["dt"]).getTime()) {
			  return -1;
		  } else {
			  return 0;
		  }
	  });
	  
	  this.nextMatchId = upcomingmatches[0]['id'];
	  this.nextMatchTime = upcomingmatches[0]['dt'];
	  
	  //console.log('Number of live matches :'+matches.length);
	  
	  if(livematches.length===0) {
		  this.requestLiveMatchMetadata();
		  return;
	  }
	  
	  //Take the first match that is currently LIVE - Should only be one according to the schedule
	  this.liveMatchId = livematches[0]['id'];
	  this.liveMatchScore = livematches[0]['r'];
	  this.liveMatchMin = livematches[0]['min']==='fifa.half-time'?'Half Time':livematches[0]['min'];
	  
	  /*
	  this.liveMatchId = '300186471';
	  this.liveMatchScore = '3-0';
	  this.liveMatchMin = "67'";
	  */
	  
	  this.requestLiveMatchMetadata();
	  
	  var _this = this;
	  window.setTimeout(function() {
		  _this.liveMatchId = null;
		  _this.requestLiveMatchMetadata();
	  }, 2000);
  },
  
  requestLiveMatchMetadata: function() {  
	    var req = new XMLHttpRequest();
	    var curDate = new Date();
	    var stage = (curDate.getTime()>this.secondStageStartDate.getTime())?'secondstage':'255931';
	    var matchId = (this.liveMatchId==null)?this.nextMatchId:this.liveMatchId;
	    req.open("GET", 'http://lup.fifa.com/live/common/competitions/worldcup/round='+stage+'/match='+matchId+'/lang=en/channels/sentinel/liveblog.js', true);
	    req.onload = this.processLiveMatchMetadata.bind(this);
	    req.send(null);
  },
  
  processLiveMatchMetadata: function(e) {
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var liveObj = JSON.parse(jsonText);
	  var fragmentUrl = liveObj['fragment_url'];
	  this.requestLiveMatchInfo(fragmentUrl);
  },
  
  requestLiveMatchInfo: function(fragmentUrl) {  
	  var req = new XMLHttpRequest();
	  req.open("GET", fragmentUrl, true);
	  req.onload = this.processLiveMatchInfo.bind(this);
	  req.send(null);
  },
  
  processLiveMatchInfo: function(e) {
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var liveObj = JSON.parse(jsonText);
	  var title = liveObj['Name'];
	  title = title.substring(0, title.indexOf('['));
	  title = title.replace("FWC 2014 - ", "");
	  
	  var live = (this.liveMatchId!=null);
	  
	  if(live) {
		  $("#matchSummary").append("<span style='float:left'>Live Score</span><span style='float:right'>Match Clock : "+this.liveMatchMin+"</span><br><span style='font-size:18px;color:#002EB8'>"+title+"<br>"+this.liveMatchScore+"</span><br>");
	  } else {
		  var nextMatchStartTime = new Date(this.nextMatchTime);
		  nextMatchStartTime.setHours(nextMatchStartTime.getHours()+3);
		  $("#matchSummary").append("<hr>Up Next : <br><span style='font-size:18px'>"+title+"</span><br>"+nextMatchStartTime);
	  }
	  
  }
  
  
};

FifaWorldCup2014.requestOngoingMatchesInfo();

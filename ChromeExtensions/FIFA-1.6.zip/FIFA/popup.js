var FifaWorldCup2014 = {

  matchesUrl: 'http://lup.fifa.com/live/common/competitions/worldcup/_feed/_listmachlive.js',
  liveMatchId: null,
  nextMatchId: null,
  nextMatchTime: null,
  lastMatchId: null,
  liveMatchScore: null, 
  tournmentEndDate: new Date(2014,6,15),
  secondStageStartDate: new Date(2014,5,27),
  
  requestOngoingMatchesInfo: function() {
	  
	  $("#matchSummary").empty();
	  
	  var curDate = new Date();
	  if(curDate.getTime() > this.tournmentEndDate.getTime()) {
		  var message = 'The tournment has ended.. It is always a good idea to clean up after yourself. Please uninstall this extension by right-clicking on the icon and choosing to remove from Chrome. Thank you very much for your support.';
		  $("#matchSummary").html(message);
		  return;
	  }
	  
	  var req = new XMLHttpRequest();
	  req.open("GET", this.matchesUrl, true);
	  req.onload = this.processOngoingMatchesInfo.bind(this);
	  req.send(null);
  },
  
  processOngoingMatchesInfo: function(e) {
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var ongoingObj = JSON.parse(jsonText);
	  var matches = ongoingObj['matches'];
	  //console.log('Number of matches :'+matches.length);
	  var livematches = $.grep(matches, function(o,i) {
		  return o['s']==='live';
	  });
	  
	  var upcomingmatches = $.grep(matches, function(o,i) {
		  return o['s']==='fixture';
	  });
	  
	  var completedmatches = $.grep(matches, function(o,i) {
		  return o['s']==='result';
	  });
	  
	  upcomingmatches = upcomingmatches.sort(function(a,b) {
		  if(new Date(a["dt"]).getTime()>new Date(b["dt"]).getTime()) {
			  return 1;
		  } else if(new Date(a["dt"]).getTime()<new Date(b["dt"]).getTime()) {
			  return -1;
		  } else {
			  return 0;
		  }
	  });
	  
	  completedmatches = completedmatches.sort(function(a,b) {
		  if(new Date(a["dt"]).getTime()>new Date(b["dt"]).getTime()) {
			  return -1;
		  } else if(new Date(a["dt"]).getTime()<new Date(b["dt"]).getTime()) {
			  return 1;
		  } else {
			  return 0;
		  }
	  });
	  
	  if(upcomingmatches.length!==0) {
		  this.nextMatchId = upcomingmatches[0]['id'];
		  this.nextMatchTime = upcomingmatches[0]['dt'];
	  }
	  
	  /*
	  this.nextMatchId = '300186477';
	  this.nextMatchTime = '2014-06-15T19:00:00';
	  */
	  if(completedmatches.length!==0) {
		  this.lastMatchId = completedmatches[0]['id'];
		  this.lastMatchScore = completedmatches[0]['r'];
		  this.lastMatchMin = completedmatches[0]['min']==='fifa.full-time'?'Full Time':completedmatches[0]['min'];
	  }
	  
	  //console.log('Number of live matches :'+livematches.length);
	  //console.log('Number of upcoming matches :'+upcomingmatches.length);
	  
	  if(livematches.length!==0) {
		  //Take the first match that is currently LIVE - Should only be one according to the schedule
		  this.liveMatchId = livematches[0]['id'];
		  this.liveMatchScore = livematches[0]['r'];
		  this.liveMatchMin = livematches[0]['min']==='fifa.half-time'?'Half Time':livematches[0]['min'];
	  }
	  
	  /*
	  this.liveMatchId = '300186471';
	  this.liveMatchScore = '3-0';
	  this.liveMatchMin = "67'";
	  */
	  
	  if(this.lastMatchId!=null) {
		  this.requestLastMatchMetadata();
	  }
	  if(this.liveMatchId!=null) {
		  this.requestLiveMatchMetadata();
	  }
	  if(this.nextMatchId!=null) {
		  this.requestNextMatchMetadata();
	  }
	  
	  if(this.liveMatchId==null && this.nextMatchId==null && this.lastMatchId==null) {
		  $("#noMatchSummary").removeClass("hide");
	  }
	  
  },
  
  requestLiveMatchMetadata: function() {  
	    var req = new XMLHttpRequest();
	    var curDate = new Date();
	    var stage = (curDate.getTime()>this.secondStageStartDate.getTime())?'secondstage':'255931';
	    var matchId = this.liveMatchId;
	    req.open("GET", 'http://lup.fifa.com/live/common/competitions/worldcup/round='+stage+'/match='+matchId+'/lang=en/channels/sentinel/liveblog.js', true);
	    req.onload = this.processLiveMatchMetadata.bind(this);
	    req.send(null);
  },
  
  processLiveMatchMetadata: function(e) {
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var liveObj = JSON.parse(jsonText);
	  var fragmentUrl = liveObj['fragment_url'];
	  this.requestLiveMatchInfo(fragmentUrl);
  },
  
  requestLiveMatchInfo: function(fragmentUrl) {  
	  var req = new XMLHttpRequest();
	  req.open("GET", fragmentUrl, true);
	  req.onload = this.processLiveMatchInfo.bind(this);
	  req.send(null);
  },
  
  processLiveMatchInfo: function(e) {
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var liveObj = JSON.parse(jsonText);
	  var title = liveObj['Name'];
	  title = title.substring(0, title.indexOf('['));
	  title = title.replace("FWC 2014 - ", "");
	  
	  $("#liveMatchSummary").removeClass("hide").html("<span style='float:left'>Live Score</span><span style='float:right'>Match Clock : "+this.liveMatchMin+"</span><br><span style='font-size:18px;'>"+title+"<br>"+this.liveMatchScore+"</span>");
	  
  },
  
  /* Next Match Information */
  
  requestNextMatchMetadata: function() {  
	    var req = new XMLHttpRequest();
	    var curDate = new Date();
	    var stage = (curDate.getTime()>this.secondStageStartDate.getTime())?'secondstage':'255931';
	    var matchId = this.nextMatchId;
	    req.open("GET", 'http://lup.fifa.com/live/common/competitions/worldcup/round='+stage+'/match='+matchId+'/lang=en/channels/sentinel/liveblog.js', true);
	    req.onload = this.processNextMatchMetadata.bind(this);
	    req.send(null);
	},
	
	processNextMatchMetadata: function(e) {
		  var resp = e.target.responseText;
		  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
		  if(jsonText==='') {
			  return;
		  }
		  var liveObj = JSON.parse(jsonText);
		  var fragmentUrl = liveObj['fragment_url'];
		  this.requestNextMatchInfo(fragmentUrl);
	},
	
	requestNextMatchInfo: function(fragmentUrl) {  
		  var req = new XMLHttpRequest();
		  req.open("GET", fragmentUrl, true);
		  req.onload = this.processNextMatchInfo.bind(this);
		  req.send(null);
	},
	
	processNextMatchInfo: function(e) {
		  var resp = e.target.responseText;
		  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
		  if(jsonText==='') {
			  return;
		  }
		  var nextObj = JSON.parse(jsonText);
		  var title = nextObj['Name'];
		  title = title.substring(0, title.indexOf('['));
		  title = title.replace("FWC 2014 - ", "");

		  var nextMatchStartTime = new Date(this.nextMatchTime);
		  nextMatchStartTime.setHours(nextMatchStartTime.getHours()+3);
		  console.log(nextMatchStartTime);
		  $("#upcomingMatchSummary").removeClass("hide").html("<span style='float:left'>Up Next</span><br><span style='font-size:18px'>"+title+"</span><br>"+this.humanFormat(nextMatchStartTime));
		  
	},

	/* Last Match Information */
	  
	requestLastMatchMetadata: function() {  
	    var req = new XMLHttpRequest();
	    var curDate = new Date();
	    var stage = (curDate.getTime()>this.secondStageStartDate.getTime())?'secondstage':'255931';
	    var matchId = this.lastMatchId;
	    req.open("GET", 'http://lup.fifa.com/live/common/competitions/worldcup/round='+stage+'/match='+matchId+'/lang=en/channels/sentinel/liveblog.js', true);
	    req.onload = this.processLastMatchMetadata.bind(this);
	    req.send(null);
	},
	
	processLastMatchMetadata: function(e) {
		  var resp = e.target.responseText;
		  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
		  if(jsonText==='') {
			  return;
		  }
		  var liveObj = JSON.parse(jsonText);
		  var fragmentUrl = liveObj['fragment_url'];
		  this.requestLastMatchInfo(fragmentUrl);
	},
	
	requestLastMatchInfo: function(fragmentUrl) {  
		  var req = new XMLHttpRequest();
		  req.open("GET", fragmentUrl, true);
		  req.onload = this.processLastMatchInfo.bind(this);
		  req.send(null);
	},
	
	processLastMatchInfo: function(e) {
		  var resp = e.target.responseText;
		  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
		  if(jsonText==='') {
			  return;
		  }
		  var lastObj = JSON.parse(jsonText);
		  var title = lastObj['Name'];
		  title = title.substring(0, title.indexOf('['));
		  title = title.replace("FWC 2014 - ", "");
		  
		  $("#completedMatchSummary").removeClass("hide").html("<span style='float:left'>Completed Match</span><span style='float:right'>"+this.lastMatchMin+"</span><br><span style='font-size:18px;'>"+title+"<br>"+this.lastMatchScore+"</span><br>");
		  
	},
	
	humanFormat: function(dateOne){
		var now = new Date();
		console.log(now);
		var ms = dateOne.getTime()-now.getTime();
	    var x = ms / 1000;
	    seconds = parseInt(x % 60);
	    x /= 60;
	    minutes = parseInt(x % 60);
	    x /= 60;
	    hours = parseInt(x % 24);
	    x /= 24;
	    days = parseInt(x);

	    return hours + " hours " + minutes + " minutes " + seconds + " seconds to go";
	}
	
  
};

FifaWorldCup2014.requestOngoingMatchesInfo();

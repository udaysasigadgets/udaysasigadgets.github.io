var FifaWorldCup2018 = {

  matchesUrl: 'https://api.fifa.com/api/v1/calendar/matches?idseason=254645&idcompetition=17&language=en-GB&count=100',
  //liveMatchId: null,
  //nextMatchId: null,
  //nextMatchTime: null,
  //lastMatchId: null,
  //liveMatchScore: null,
  
  lastMatches: [],
  liveMatches: [],
  nextMatches: [],
  
  tournmentEndDate: new Date(2018,6,15),
  
  requestOngoingMatchesInfo: function() {
	  var _this = this;

	  var curDate = new Date();
	  if(curDate.getTime() > this.tournmentEndDate.getTime()) {
		  //Do not show this message for another day
		  if(curDate.getTime()-parseInt(this.tournmentDoneMsgDate, 10)>1000*60*60*24) {
			  this.tournmentDoneMsgDate = curDate.getTime();
			  localStorage['tournmentDoneMsgDate'] = this.tournmentDoneMsgDate;
			  this.displayUninstallMessage();
		  } 
		  return;
	  }
	  
	  $.getJSON(this.matchesUrl, function(resp) {
		  _this.processOngoingMatchesInfo(resp.Results);
	  });
  },
  
  processOngoingMatchesInfo: function(matches) {
	  var _this = this;
	  console.log('Number of matches : '+ matches.length);
	  var completedMatches = $.grep(matches, function(match) {
		 return match.MatchStatus===0;
	  });
	  console.log('Number of completed matches : '+ completedMatches.length);
	  
	  var ongoingMatches = $.grep(matches, function(match) {
		 return match.MatchStatus===3;
	  });
	  console.log('Number of ongoing matches : '+ ongoingMatches.length);
	  
	  var upcomingMatches = $.grep(matches, function(match) {
		 return match.MatchStatus===1;
	  });
	  console.log('Number of upcoiming matches : '+ upcomingMatches.length);
	  
	  //Process completedMatches
	  if(completedMatches.length>0) {
		  var completedMatchToDisplay = completedMatches[completedMatches.length-1];
		  var homeTeam = completedMatchToDisplay.Home, awayTeam = completedMatchToDisplay.Away;
		  var winningTeam = completedMatchToDisplay.Winner;
		  var html = '<div class="summary">'
			  		+	'<div class="row">'
			  		+ 		'<div class="col-xs-5 '+((homeTeam['IdTeam']===winningTeam)?'strong':'')+'">'
			  		+			'<img class="small-flag" src="https://api.fifa.com/api/v1/picture/flags-fwc2018-3/'+homeTeam['IdCountry']+'">'+homeTeam['TeamName'][0]['Description']+'<br>'
		  			+			'<span class="score">'+homeTeam['Score']+'</span>'
		  			+		'</div>'
			  		+	 	'<div class="col-xs-2"><br>vs</div>'
			  		+ 		'<div class="col-xs-5 '+((awayTeam['IdTeam']===winningTeam)?'strong':'')+'">'
			  		+			'<img class="small-flag" src="https://api.fifa.com/api/v1/picture/flags-fwc2018-3/'+awayTeam['IdCountry']+'">'+awayTeam['TeamName'][0]['Description']+'<br>'
			  		+			'<span class="score">'+awayTeam['Score']+'</span>'
		  			+		'</div>'
		  			+	'</div>'
		  			+	'<div class="row">'
		  			+ 		'<div class="col-xs-12">'
		  			+			'<span class="footer-text">(Match ended '+moment(completedMatchToDisplay['LocalDate']).fromNow()+')</span>'
		  			+		'</div>'
			  		+	'</div>';
		  			+'</div>';
		  $("#completedMatchSummary").append(html).removeClass('hide');
	  }
	  
	  //Process ongoingMatches
	  if(ongoingMatches.length>0) {
		  $.each(ongoingMatches, function(i, ongoingMatchToDisplay) {
			  var homeTeam = ongoingMatchToDisplay.Home, awayTeam = ongoingMatchToDisplay.Away;
			  var winningTeam = ongoingMatchToDisplay.Winner;
			  var html = '<div class="summary ongoing-summary">'
				  		+	'<div class="row">'
				  		+ 		'<div class="col-xs-5 '+((homeTeam['IdTeam']===winningTeam)?'strong':'')+'">'
				  		+			'<img class="small-flag" src="https://api.fifa.com/api/v1/picture/flags-fwc2018-3/'+homeTeam['IdCountry']+'">'+homeTeam['TeamName'][0]['Description']+'<br>'
			  			+			'<span class="score">'+homeTeam['Score']+'</span>'
			  			+		'</div>'
				  		+	 	'<div class="col-xs-2"><br>vs</div>'
				  		+ 		'<div class="col-xs-5 '+((awayTeam['IdTeam']===winningTeam)?'strong':'')+'">'
				  		+			'<img class="small-flag" src="https://api.fifa.com/api/v1/picture/flags-fwc2018-3/'+awayTeam['IdCountry']+'">'+awayTeam['TeamName'][0]['Description']+'<br>'
				  		+			'<span class="score">'+awayTeam['Score']+'</span>'
			  			+		'</div>'
			  			+	'</div>'
			  			+	'<div class="row">'
			  			+ 		'<div class="col-xs-12">'
			  			+			'<div class="footer-text"><img src="loading.svg" width="25" class="pull-right">(Match time: '+ongoingMatchToDisplay['MatchTime']+')</div>'
			  			+		'</div>'
				  		+	'</div>';
			  			+'</div>';
			  $("#completedMatchSummary").append(html).removeClass('hide');		
		  });
		  
	  }
	  
	  //Process upcomingMatches
	  if(upcomingMatches.length>0) {
		  var upcomingMatchToDisplay = upcomingMatches[0];
		  var homeTeam = upcomingMatchToDisplay.Home, awayTeam = upcomingMatchToDisplay.Away;
		  var html = '<div class="summary">'
			  		+	'<div class="row">'
			  		+ 		'<div class="col-xs-5">'
			  		+			'<img class="small-flag" src="https://api.fifa.com/api/v1/picture/flags-fwc2018-3/'+homeTeam['IdCountry']+'">'+homeTeam['TeamName'][0]['Description']+'<br>'
		  			+		'</div>'
			  		+	 	'<div class="col-xs-2">vs</div>'
			  		+ 		'<div class="col-xs-5">'
			  		+			'<img class="small-flag" src="https://api.fifa.com/api/v1/picture/flags-fwc2018-3/'+awayTeam['IdCountry']+'">'+awayTeam['TeamName'][0]['Description']+'<br>'
		  			+		'</div>'
		  			+	'</div>'
		  			+	'<div class="row">'
		  			+ 		'<div class="col-xs-12">'
		  			+			'<span class="footer-text"><br>(Match starts '+moment(upcomingMatchToDisplay['Date']).fromNow()+')</span>'
		  			+		'</div>'
			  		+	'</div>';
		  			+'</div>';
		  $("#upcomingMatchSummary").append(html).removeClass('hide');
	  }
	  
  },
  
  processOngoingMatchesInfoOld: function(e) {
	  var _this = this;
	  
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var ongoingObj = JSON.parse(jsonText);
	  var matches = ongoingObj['matches'];
	  //console.log('Number of matches :'+matches.length);
	  var livematches = $.grep(matches, function(o,i) {
		  return o['s']==='live';
	  });
	  
	  var upcomingmatches = $.grep(matches, function(o,i) {
		  return o['s']==='fixture';
	  });
	  
	  var completedmatches = $.grep(matches, function(o,i) {
		  return o['s']==='result';
	  });
	  
	  upcomingmatches = upcomingmatches.sort(function(a,b) {
		  if(new Date(a["dt"]).getTime()>new Date(b["dt"]).getTime()) {
			  return 1;
		  } else if(new Date(a["dt"]).getTime()<new Date(b["dt"]).getTime()) {
			  return -1;
		  } else {
			  return 0;
		  }
	  });
	  
	  completedmatches = completedmatches.sort(function(a,b) {
		  if(new Date(a["dt"]).getTime()>new Date(b["dt"]).getTime()) {
			  return -1;
		  } else if(new Date(a["dt"]).getTime()<new Date(b["dt"]).getTime()) {
			  return 1;
		  } else {
			  return 0;
		  }
	  });
	  
	  if(upcomingmatches.length!==0) {
		  $.each(upcomingmatches, function(i,match) {
			 _this.nextMatches[match['id']] = {
					 'nextMatchTime' : match['dt']
			 };
			 
			 _this.requestNextMatchMetadata(match['id']);
		  });
		  /*
		  this.nextMatchId = upcomingmatches[0]['id'];
		  this.nextMatchTime = upcomingmatches[0]['dt'];
		  */
	  }
	  
	  /*
	  this.nextMatchId = '300186477';
	  this.nextMatchTime = '2014-06-15T19:00:00';
	  */
	  if(completedmatches.length!==0) {
		  $.each(completedmatches, function(i,match) {
			 _this.lastMatches[match['id']] = {
					 'lastMatchScore' : match['r'],
					 'lastMatchMin' : match['min']==='fifa.full-time'?'Full Time':match['min']
			 };
			 
			 _this.requestLastMatchMetadata(match['id']);
		  });
		  /*
		  this.lastMatchId = completedmatches[0]['id'];
		  this.lastMatchScore = completedmatches[0]['r'];
		  this.lastMatchMin = completedmatches[0]['min']==='fifa.full-time'?'Full Time':completedmatches[0]['min'];
		  */
	  }
	  
	  //console.log('Number of live matches :'+livematches.length);
	  //console.log('Number of upcoming matches :'+upcomingmatches.length);
	  
	  if(livematches.length!==0) {
		  $.each(livematches, function(i,match) {
			 _this.liveMatches[match['id']] = {
					 'lastMatchScore' : match['r'],
					 'lastMatchMin' : match['min']==='fifa.half-time'?'Half Time':match['min']
			 };
			 console.log('Added '+match['id']+' to the Map');
			 _this.requestLiveMatchMetadata(match['id']);
		  });
		  /*
		  //Take the first match that is currently LIVE - Should only be one according to the schedule
		  this.liveMatchId = livematches[0]['id'];
		  this.liveMatchScore = livematches[0]['r'];
		  this.liveMatchMin = livematches[0]['min']==='fifa.half-time'?'Half Time':livematches[0]['min'];
		  */
	  }
	  
	  /*
	  this.liveMatchId = '300186471';
	  this.liveMatchScore = '3-0';
	  this.liveMatchMin = "67'";
	  */
	  
	  /*
	  if(this.lastMatchId!=null) {
		  this.requestLastMatchMetadata();
	  }
	  if(this.liveMatchId!=null) {
		  this.requestLiveMatchMetadata();
	  }
	  if(this.nextMatchId!=null) {
		  this.requestNextMatchMetadata();
	  }
	  */
	  if(upcomingmatches.length===0) {
		  $("#noMatchSummary").removeClass("hide");
	  }
	  
  },
  
  requestLiveMatchMetadata: function(matchId) {  
	    var req = new XMLHttpRequest();
	    var stage = this.getCurrentStage();
	    //var stage = (curDate.getTime()>this.secondStageStartDate.getTime())?'255951':'255931';
	    //var matchId = this.liveMatchId;
	    req.open("GET", 'http://lup.fifa.com/live/common/competitions/worldcup/round='+stage+'/match='+matchId+'/lang=en/channels/sentinel/liveblog.js', true);
	    req.onload = this.processLiveMatchMetadata.bind(this);
	    req.send(null);
  },
  
  processLiveMatchMetadata: function(e) {
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var liveObj = JSON.parse(jsonText);
	  var fragmentUrl = liveObj['fragment_url'];
	  this.requestLiveMatchInfo(fragmentUrl);
  },
  
  requestLiveMatchInfo: function(fragmentUrl) {  
	  var req = new XMLHttpRequest();
	  req.open("GET", fragmentUrl, true);
	  req.onload = this.processLiveMatchInfo.bind(this);
	  req.send(null);
  },
  
  processLiveMatchInfo: function(e) {
	  var _this = this;
	  var resp = e.target.responseText;
	  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
	  if(jsonText==='') {
		  return;
	  }
	  var liveObj = JSON.parse(jsonText);
	  var title = liveObj['Name'];
	  title = title.substring(0, title.indexOf('['));
	  title = title.replace("FWC 2014 - ", "");
	  
	  var matchId = liveObj['Name'];
	  matchId = matchId.substring(matchId.indexOf(':')+1, matchId.indexOf(']'));
	  
	  console.log(JSON.stringify(_this.liveMatches));
	  var liveMatchMin = _this.liveMatches[matchId]['lastMatchMin'];
	  var liveMatchScore = _this.liveMatches[matchId]['lastMatchScore'];
	  
	  $("#liveMatchSummary").removeClass("hide").append("<span style='float:left'>Live Score</span><span style='float:right'>Match Clock : "+liveMatchMin+"</span><br><span style='font-size:18px;'>"+title+"<br>"+liveMatchScore+"</span><br>");
	  
  },
  
  /* Next Match Information */
  
  requestNextMatchMetadata: function(matchId) {  
	    var req = new XMLHttpRequest();
	    var stage = this.getCurrentStage();
	    //var stage = (curDate.getTime()>this.secondStageStartDate.getTime())?'255951':'255931';
	    //var matchId = this.nextMatchId;
	    req.open("GET", 'http://lup.fifa.com/live/common/competitions/worldcup/round='+stage+'/match='+matchId+'/lang=en/channels/sentinel/liveblog.js', true);
	    req.onload = this.processNextMatchMetadata.bind(this);
	    req.send(null);
	},
	
	processNextMatchMetadata: function(e) {
		  var resp = e.target.responseText;
		  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
		  if(jsonText==='') {
			  return;
		  }
		  var liveObj = JSON.parse(jsonText);
		  var fragmentUrl = liveObj['fragment_url'];
		  this.requestNextMatchInfo(fragmentUrl);
	},
	
	requestNextMatchInfo: function(fragmentUrl) {  
		  var req = new XMLHttpRequest();
		  req.open("GET", fragmentUrl, true);
		  req.onload = this.processNextMatchInfo.bind(this);
		  req.send(null);
	},
	
	processNextMatchInfo: function(e) {
		  var resp = e.target.responseText;
		  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
		  if(jsonText==='') {
			  return;
		  }
		  var nextObj = JSON.parse(jsonText);
		  var title = nextObj['Name'];
		  title = title.substring(0, title.indexOf('['));
		  title = title.replace("FWC 2014 - ", "");

		  var matchId = nextObj['Name'];
		  matchId = matchId.substring(matchId.indexOf(':')+1, matchId.indexOf(']'));
		  
		  var nextMatchStartTime = new Date(this.nextMatches[matchId]['nextMatchTime']);
		  if(this.specialVenueMatches.indexOf(matchId)!==-1) {
			  nextMatchStartTime.setHours(nextMatchStartTime.getHours()+4);  
		  } else {
			  nextMatchStartTime.setHours(nextMatchStartTime.getHours()+3);
		  }
		  
		  //console.log(nextMatchStartTime);
		  $("#upcomingMatchSummary").removeClass("hide").append("<span style='float:left'>Up Next</span><br><span style='font-size:18px'>"+title+"</span><br>"+this.humanFormat(nextMatchStartTime)+"<br>");
		  
	},

	/* Last Match Information */
	  
	requestLastMatchMetadata: function(matchId) {  
	    var req = new XMLHttpRequest();
	    var stage = this.getCurrentStage();
	    //var stage = (curDate.getTime()>this.secondStageStartDate.getTime())?'255951':'255931';
	    //var matchId = this.lastMatchId;
	    req.open("GET", 'http://lup.fifa.com/live/common/competitions/worldcup/round='+stage+'/match='+matchId+'/lang=en/channels/sentinel/liveblog.js', true);
	    req.onload = this.processLastMatchMetadata.bind(this);
	    req.send(null);
	},
	
	processLastMatchMetadata: function(e) {
		  var resp = e.target.responseText;
		  var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
		  if(jsonText==='') {
			  return;
		  }
		  var liveObj = JSON.parse(jsonText);
		  var fragmentUrl = liveObj['fragment_url'];
		  this.requestLastMatchInfo(fragmentUrl);
	},
	
	requestLastMatchInfo: function(fragmentUrl) {  
		  var req = new XMLHttpRequest();
		  req.open("GET", fragmentUrl, true);
		  req.onload = this.processLastMatchInfo.bind(this);
		  req.send(null);
	},
	
	processLastMatchInfo: function(e) {
		var _this = this;
		var resp = e.target.responseText;
		var jsonText = resp.substring(resp.indexOf("(")+1, resp.lastIndexOf(")"));
		if(jsonText==='') {
			return;
		}
		var lastObj = JSON.parse(jsonText);
		var title = lastObj['Name'];
		title = title.substring(0, title.indexOf('['));
		title = title.replace("FWC 2014 - ", "");
		  
		var matchId = lastObj['Name'];
		matchId = matchId.substring(matchId.indexOf(':')+1, matchId.indexOf(']'));
		  
		var lastMatchMin = _this.lastMatches[matchId]['lastMatchMin'];
		var lastMatchScore = _this.lastMatches[matchId]['lastMatchScore'];
		  
		$("#completedMatchSummary").removeClass("hide").append("<span style='float:left'>Completed</span><span style='float:right'>"+lastMatchMin+"</span><br><span style='font-size:18px;'>"+title+"<br>"+lastMatchScore+"</span><br>");
	},
	
	humanFormat: function(dateOne){
		var now = new Date();
		//console.log(now);
		var ms = dateOne.getTime()-now.getTime();
	    var x = ms / 1000;
	    seconds = parseInt(x % 60);
	    x /= 60;
	    minutes = parseInt(x % 60);
	    x /= 60;
	    hours = parseInt(x % 24);
	    x /= 24;
	    days = parseInt(x);

	    if(hours<0 || minutes<0 || seconds<0) {
	    	return ""
	    }
	    return hours + " hours " + minutes + " minutes " + seconds + " seconds to go";
	}
	
  
};

FifaWorldCup2018.requestOngoingMatchesInfo();

var IccWorldCup2015 = {

  matchesUrl: 'http://static.cricinfo.com/rss/livescores.xml',
  liveMatches: {},
  tournmentEndDate: new Date(2015,3,1),
  
  myTeams : null,
  myEvents : null,

  service : null, 
  tracker: null,
  init : function() {
	  var _this = this;
	  try {
		  this.service = analytics.getService('ICC_2105_Live_Updates');
		  this.service.getConfig().addCallback(function() {
			  //console.log('analytics service created');
		  });
		  this.tracker = this.service.getTracker('UA-1214589-33');
		  this.tracker.sendAppView('PopupView');
	  } catch(e) {
		  
	  }
	  
	  var myEvents = localStorage['myEvents'];
      if(myEvents==null) {
        myEvents = ["FOUR", "SIX", "OUT"];
        localStorage['myEvents'] = myEvents;
      }
      var myTeams = localStorage['myTeams'];
      if(myTeams==null) {
        myTeams = ["England", "South Africa", "India", "Australia", "Sri Lanka", "Pakistan", "West Indies", "Bangladesh", "New Zealand", "Zimbabwe", "Ireland", "Afghanistan", "Scotland", "United Arab Emirates"];
        localStorage['myTeams'] = myTeams;
      }

	  _this.requestOngoingMatchesInfo();
  },
  
  requestOngoingMatchesInfo: function() {
	  var _this = this;
	  _this.myTeams = localStorage['myTeams'].split(',');
	  _this.myEvents = localStorage['myEvents'].split(',');
	  
	  var curDate = new Date();
	  if(curDate.getTime() > this.tournmentEndDate.getTime()) {
		  window.setTimeout(function() {
			  var message = 'Thank you very much for using the app.. I hope you enjoyed it as much as I did. <br><br>ICC World Cup 2015 is now over.. Please uninstall the extension by right-clicking on the icon and choosing "Remove". <br><br>I write apps for fun, I would really like to know what you thought about the app.. <br><br><a href="https://docs.google.com/forms/d/1Nc4TybHKgzY_t1xifQKMDAHJNPWGybiXvRbZtft0eJQ/viewform" target="share">Submit Feedback</a>';
			  $("#noMatchSummary").html(message).css({"text-align": "left"}).removeClass("hide");
		  }, 200);
		  return;
	  }
	  
	  var req = new XMLHttpRequest();
	  req.open("GET", this.matchesUrl, true);
	  req.onload = this.processOngoingMatchesInfo.bind(this);
	  req.send(null);
  },
  
  processOngoingMatchesInfo: function(e) {
  		var _this = this;
	  
	  	var resp = e.target.responseXML;
	  	var items = resp.getElementsByTagName("item");
	  	var recentmatches = [];

	  	for (var i=0;i<items.length;i++) {
	   		var title = items[i].getElementsByTagName("title")[0].childNodes[0].nodeValue;

	   		//Hack to get rid of county matches..
	   		var modifiedtitle = title.replace(/[0-9]/g, '').replace(/\//g,'').replace(/\*/g, '');
	   		var teams = modifiedtitle.split(' v ');
	   		
	   		if(_this.myTeams.indexOf(teams[0].trim())>-1 || _this.myTeams.indexOf(teams[1].trim())>-1) {
	   			recentmatches.push(title);
	   		}
	   		/*
   			for(var t=0;t<_this.myTeams.length;t++) {
   				if(title.indexOf(_this.myTeams[t])>-1) {
   					//Extract the matchid of this match
   					//var matchurl = items[i].getElementsByTagName("guid")[0].childNodes[0].nodeValue;
   					recentmatches.push(title);
				  	break;
   				}
   			}
   			*/
		}
		
	  	if(recentmatches.length===0) {
			$("#noMatchSummary").removeClass("hide");
	  	} else {
	  		for(var i=0;i<recentmatches.length-1;i++) {
	  			$("#liveMatchSummary").removeClass("hide").append("<span style='font-size:14px;'>"+recentmatches[i]+"</span><hr>");
	  		}
	  		$("#liveMatchSummary").removeClass("hide").append("<span style='font-size:14px;'>"+recentmatches[recentmatches.length-1]+"</span>");
	  	}
	  
  },
	
	humanFormat: function(dateOne){
		var now = new Date();
		//console.log(now);
		var ms = dateOne.getTime()-now.getTime();
	    var x = ms / 1000;
	    seconds = parseInt(x % 60);
	    x /= 60;
	    minutes = parseInt(x % 60);
	    x /= 60;
	    hours = parseInt(x % 24);
	    x /= 24;
	    days = parseInt(x);

	    if(hours<0 || minutes<0 || seconds<0) {
	    	return ""
	    }
	    return hours + " hours " + minutes + " minutes " + seconds + " seconds to go";
	}
	
  
};

IccWorldCup2015.init();

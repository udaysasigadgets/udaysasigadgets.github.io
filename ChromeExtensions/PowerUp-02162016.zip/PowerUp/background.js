
var PowerUp = {

  chargepointUrl: 'https://na.chargepoint.com/dashboard/getChargeSpots',
  liveMatches: {},
  
  myTeams : null,
  myEvents : null,

  service : null, 
  tracker: null,
  notify: false,

  loggedInUser: null,
  cardSerialNumber: null,

  init : function() {
	  var _this = this;
	  /*
	  try {
		  this.service = analytics.getService('PowerUp_Live_Updates');
		  this.service.getConfig().addCallback(function() {
			  //console.log('analytics service created');
		  });
		  this.tracker = this.service.getTracker('UA-1214589-34');
		  this.tracker.sendAppView('MainView');
	  } catch(e) {
		  
	  }
	  */
	  
	  _this.requestChargingStationInfo();
  },
  
  requestChargingStationInfo: function() {
	  	var _this = this;
	  	
	  	var bounds, prefBounds = localStorage['b'];
      	if(prefBounds) {
       		bounds = JSON.parse(prefBounds);
       		_this.chargepointUrl = 'https://na.chargepoint.com/dashboard/getChargeSpots?ne_lat='+bounds['ne']['lat']+'&ne_lng='+bounds['ne']['lng']+'&sw_lat='+bounds['sw']['lat']+'&sw_lng='+bounds['sw']['lng'];
      	} else {
      		return;
      	}
	  	setTimeout(function() {
			_this.requestChargingStationInfo();
	  	}, 15000);
	  
	  	var req = new XMLHttpRequest();
	  	req.open("GET", this.chargepointUrl, true);
	  	req.onload = this.processChargingStationInfo.bind(this);
	  	req.send(null);
  },
  
  processChargingStationInfo: function(e) {
  		var _this = this;
  		var pn = localStorage['pn'];
  		var ps = localStorage['ps'];
	  
	  	var resp = JSON.parse(e.target.response);

	  	if(resp[0]["user_info"]["is_guest"]==1 && localStorage['ce']!=null && localStorage['cp']!=null && localStorage['ce']!='' && localStorage['cp']!='') {
	  		//User has login credentials present, Login the user
	  		var data = {"user_name": localStorage['ce'], "user_password": localStorage['cp']};
	  		$.post("https://nissan.chargepoint.com/users/validate", data, function(response) {
                response = JSON.parse(response);
            });
            return;
	  	} else {
			_this.loggedInUser = true;
	  	}
	  	if(_this.cardSerialNumber==null) {
			_this.captureChargingCardDetails();
		}

	  	//If Login fails, continue fetching station info as guest - Remember: Notifications work for guest too

	  	var numAvailableStations = 0;
	  	var stations = resp[0]["station_list"]["summaries"];
	  	$.each(stations, function(i, station) {
	  		//console.log(i+') '+station['station_status']+ ' => '+ station["station_name"].join(' '));
	  		if(station['station_status']=='available') {
	  			numAvailableStations++;
	  			//console.log('Found a station available');

				var address = [];
	  			$.map(station["address"], function(value, key) {
	  				address.push(value);
	  			});
	  			var msg = 'Charging Station '+station["station_name"].join(' ')+' is now available at '+address.join(', ');
	  			//console.log(msg);

	  			//Notify the user if notifications is turned on
				if(pn && pn=='true') {
		  			var notifTitle = 'Charging Station Available';
			  		_this.notify('powerup128.png', msg, notifTitle, 'powerup'+station['device_id']);
			  	}
			  	if(ps && ps=='true') {
			  		_this.speak(msg);
			  	}
	  		}
	  	});

	  	if(numAvailableStations>0) {
	  		chrome.browserAction.setBadgeBackgroundColor({ color: [255, 0, 0, 255] });
			chrome.browserAction.setBadgeText({text: ''+numAvailableStations});
			chrome.browserAction.setIcon({path:'powerup.png'});
		} else {
			chrome.browserAction.setIcon({path:'powerup.png'});
			chrome.browserAction.setBadgeText({text: ''});
		}

		_this.captureChargingInfo();
  },

  captureChargingCardDetails : function() {
  		var _this = this;
	  	if(_this.loggedInUser==null) {
	  		return;
	  	}
  		$.post("https://nissan.chargepoint.com/dashboard/getUsersCardList", {"isAjax": true}, function(response) {
  			response = JSON.parse(response);
  			if(response && response.content && response.content.length>0 && response.content[0] && response.content[0]['serial_number']) {
	  			_this.cardSerialNumber = response.content[0]['serial_number'];
	  		}
		});
  },

  captureChargingInfo : function() {
  		var _this = this;
  		if(_this.cardSerialNumber==null) {
  			return;
  		}
  		$.post("https://nissan.chargepoint.com/dashboard/getRealTimeStatusGraph", {'serialNumber': _this.cardSerialNumber}, function(response) {
  			response = JSON.parse(response);
  			if(response && response.content && response.content.length>0 && response.content[0]) {
  				var power = response.content[0]['power'];
	  			if(power<0.5) {
	  				var pn = localStorage['pn'];
	  				var ps = localStorage['ps'];
	  				//Notify the user if notifications is turned on
	  				var notifTitle = 'Charging almost complete';
			  		var msg = 'Your vehicle plugged in at '+response.content[0]['address']+' may be fully charged';
					//if(pn && pn=='true') { //Show visual notification regardless of setting
				  		_this.notify('powerup128.png', msg, notifTitle, 'powerup'+response.content[0]['id']);
				  	//}
				  	//Audio notification only if enabled
				  	if(ps && ps=='true') {
				  		_this.speak(msg);
				  	}
	  			}
  			}
		});
  },

  notify : function(img, msg, notifTitle, stationId) {
  		var opt = {
			type: 'basic',
			iconUrl: img,
			title: notifTitle,
			message: msg,
			isClickable: true
	  	};
	  	chrome.notifications.create(stationId, opt, function(notifId) { 
	  		if(chrome.runtime.lastError) {
	  			console.log('NotifID '+notifId+' created - Last error:', chrome.runtime.lastError);
	  		}
	  	});
	  	
	    setTimeout(function(){
	    	chrome.notifications.clear(stationId, function() {
	    		if(chrome.runtime.lastError) {
	    			console.log(chrome.runtime.lastError);
	    		}
	    	});
	    }, 10000);
  }, 

  speak : function(msg) {
	    chrome.tts.speak(msg, {'voiceName': 'Google US English'});
  }
  
};

PowerUp.init();

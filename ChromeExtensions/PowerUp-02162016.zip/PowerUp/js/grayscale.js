$( document ).ready(function() {

    var map, geocoder;
    var boundsChangeTimeout = null;
    var markers = [];

    function initMap() {

        geocoder = new google.maps.Geocoder();

        var prefZoom = localStorage['z'];
        var mapZoom, mapCenter;
        if(prefZoom) {
            var perfCenter = JSON.parse(localStorage['c']);
            mapZoom = parseInt(prefZoom, 10);
            mapCenter = perfCenter;
        } else {
            mapZoom = 4;
            mapCenter = {lat: -39.10, lng: -98.43};
        }

        map = new google.maps.Map(document.getElementById('map'), {
            center: mapCenter,
            zoom: mapZoom
        });

        map.addListener('bounds_changed', function() {
            if(boundsChangeTimeout) {
                clearTimeout(boundsChangeTimeout);
            }
            boundsChangeTimeout = setTimeout(function() {
                //console.log('Zoom: ' + map.getZoom());
                //console.log('Current Center: '+map.getCenter());

                var bounds = map.getBounds();
                var ne = bounds.getNorthEast();
                var sw = bounds.getSouthWest();

                var b = {
                    'ne' : {
                        'lat' : ne.lat(), 'lng': ne.lng()
                    },
                    'sw' : {
                        'lat' : sw.lat(), 'lng': sw.lng()
                    }
                }
                

                var center = map.getCenter();
                var c = { 'lat' : center.lat(), 'lng': center.lng() };
                localStorage['z'] = map.getZoom();
                localStorage['c'] = JSON.stringify(c);
                localStorage['b'] = JSON.stringify(b);

                //Delete all markers on the Map
                deleteMarkers();

                //Load all the charging stations on the map
                var u = 'scWidth=1425&scHeight=912&f_estimationfee=false&f_available=true&f_inuse=true&f_unknown=true&f_cp=true&f_other=true&is_nctc_program=false&f_l3=true&f_l2=true&f_l1=true&f_estimate=false&f_fee=true&f_free=true&f_reservable=false&f_shared=true&f_chademo=true&f_saecombo=true&f_tesla=true&community=true&non_community=true&show_mode2_only=false&show_mode1_only=false';
                u += '&neLat='+b.ne.lat+'&neLng='+b.ne.lng+'&swLat='+b.sw.lat+'&swLng='+b.sw.lng;
                var params = u.split("&");
                var data = {};
                $.each(params, function(i, p) {
                    var keyval = p.split('=');
                    data[keyval[0]] = keyval[1];
                });
                $.post("https://nissan.chargepoint.com/dashboard/getMapData", data, function(resp) {
                    resp = JSON.parse(resp);
                    //console.log('Number of charging stations in the area : '+resp[0]["map_data"]["map_data_size"]);
                    $.each(resp[0]["map_data"]["summaries"], function(i, station) {
                        var myLatLng = {lat: parseFloat(station.lat, 10), lng: parseFloat(station.lon, 10)};
                        var available = station["port_count"]["available"]>0;
                        var marker = new google.maps.Marker({
                            position: myLatLng,
                            icon: available?'available16.png':'busy16.png',
                            map: map
                        });
                        markers.push(marker);
                    })
                });

            }, 500);
            

            
        });

        function clearMarkers() {
            for (var i = 0; i < markers.length; i++) {
                markers[i].setMap(null);
            }
        }
        // Deletes all markers in the array by removing references to them.
        function deleteMarkers() {
            clearMarkers();
            markers = [];
        }

        function codeAddress(address) {
            geocoder.geocode( { 'address': address}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    map.setCenter(results[0].geometry.location);
                    map.setZoom(18);
                } else {
                    console.log("Geocode was not successful for the following reason: " + status);
                }
            });
        }

        $(".searchbox input").on('keyup', function(e) {
            var code = e.which; // recommended to use e.which, it's normalized across browsers
            if(code==13){
                codeAddress($(this).val());
                $(this).blur();
            } 
        });
    }

    initMap();

    if(localStorage['ce']) {
        $('#ce').val(localStorage['ce']);
    }
    if(localStorage['cp']) {
        $('#cp').val('*******');
    }
    if(localStorage['cph']) {
        $('#cph').val(localStorage['cph']);
    }

    $(".powerupinput").blur(function() {
        var id = $(this).attr('id');
        localStorage[id] = $(this).val();
    });

    $(".clearprefs").click(function() {
        var id = $(this).attr('id');
        if(id=='loginclearprefs') {
            localStorage.removeItem('ce'); $("#ce").val('');
            localStorage.removeItem('cp'); $("#cp").val('');

        } else if(id=='phoneclearprefs') {
            localStorage.removeItem('cph'); $("#cph").val('');
        }
    });

});
Version History
---------------

1.0 - Initial version
1.1 - Highlight Amecican markets on initial load
1.1.1 - Misc changes
1.1.2 - Name changed to "Global Index Watch - Stock Markets"
1.3.1 - Added INDU as substitution to ^DJI
1.3.2 - Added missing flags and changed symbols
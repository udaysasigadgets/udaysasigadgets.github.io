Version History
---------------

1.0 - Initial version
1.1 - Highlight Amecican markets on initial load
1.1.1 - Misc changes